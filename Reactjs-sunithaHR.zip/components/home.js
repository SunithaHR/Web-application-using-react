import React, { useState, useEffect } from 'react';
import Cookies from 'js-cookie';
import { useNavigate } from 'react-router-dom';

function Home() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const token = Cookies.get('token');
    if (!token) {
      console.log('No token found, redirecting to login');
      navigate('/login');
      return;
    }

    fetch('http://localhost:8081/wordpress2/wp-json/custom-auth/v1/user', {
      headers: {
        'Authorization': token
      }
    })
    .then(response => {
      setLoading(false);
      if (!response.ok) {
        throw new Error('Failed to fetch user data');
      }
      return response.json();
    })
    .then(data => {
      if (data.username) {
        setUser(data);
        console.log('User data fetched successfully:', data);
      } else {
        throw new Error('User data not found');
      }
    })
    .catch(error => {
      console.error('Error:', error.message);
      Cookies.remove('token');
      navigate('/login');
    });
  }, [navigate]);

  return (
    <div>
      <h1>Home</h1>
      {loading ? (
        <p>Loading...</p>
      ) : (
        user ? (
          <p>Welcome, {user.username}</p>
        ) : (
          <p>No user data found</p>
        )
      )}
    </div>
  );
}

export default Home;
