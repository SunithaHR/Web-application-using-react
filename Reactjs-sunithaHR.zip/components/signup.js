import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../style.css';

function Signup() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    fetch('http://localhost:8081/wordpress2/wp-json/custom-auth/v1/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password, email })
    })
    .then(response => response.json())
    .then(data => {
      if (data.message) {
        navigate('/login');
      } else if (data.code) {
        setError(data.message);
      } else {
        setError('Failed to create user');
      }
    });
  };

  return (
    <div className='container'>
      <h1>Signup</h1>
      <form onSubmit={handleSubmit} className='container'>

        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className='m-2'
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className='m-2'
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className='m-2'
        />
        <button type="submit" className='m-2'>Signup</button>
      </form>
      {error && <p>{error}</p>}
    </div>
  );
}

export default Signup;
