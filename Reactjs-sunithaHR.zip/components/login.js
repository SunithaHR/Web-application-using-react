import React, { useState } from 'react';
import Cookies from 'js-cookie';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import '../style.css';


function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:8081/wordpress2/wp-json/custom-auth/v1/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });

      if (response.ok) {
        const data = await response.json();
        console.log(data); // Debug: Log response data

        if (data.token) {
          Cookies.set('token', data.token);
          console.log('Navigating to home'); // Debug: Log before navigation
          navigate('/');
        } else {
          console.log('Navigating to signup'); // Debug: Log before navigation
          navigate('/signup');
        }
      } else {
        const errorData = await response.json();
        console.error('Login failed:', errorData);
        setError('Invalid username or password');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('An error occurred during login');
    }
  };

  return (
    <div className='container'>
      <h1>Login</h1>
      <form onSubmit={handleLogin}>
        <label>
          Username:
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)}  className='m-2'/>
        </label>
        <br />
        <label>
          Password:
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className='m-2'/>
        </label>
        <br />
        <button type="submit" className='m-2'>Login</button>
      </form>
      <p>New user <Link to={"/signup"}>Signup</Link> </p>
      {error && <p>{error}</p>}
    </div>
  );
}

export default Login;
